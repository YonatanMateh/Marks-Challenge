//
//  YMCollectionViewCell.h
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import <UIKit/UIKit.h>
static NSString *CollectionViewCellIdentifier = @"CollectionViewCellIdentifier";

@interface YMCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) UILabel *nucleotidesView;
@end
