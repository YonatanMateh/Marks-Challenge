//
//  YMPassData.m
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import "YMPassData.h"
@interface YMPassData()
@property (strong, nonatomic) YMSetDNAStrand *setDNA;

@end
@implementation YMPassData
-(instancetype)init{
    self = [super init];
    if(self){
        _setDNA = [[YMSetDNAStrand alloc]init];
    }
    return self;
}
+(YMPassData*)ymPassData{
    static YMPassData *ymPassData;
    if(!ymPassData){
        ymPassData = [[YMPassData alloc]init];
    }
    return ymPassData;
}
-(NSMutableArray*)storedDNA{
    if(!_storedDNA){
        _storedDNA = [[NSMutableArray alloc]init];
    }
    return _storedDNA;
}


-(void)addDNASequenceOfLength:(int)length{
    [self.storedDNA addObject:[self.setDNA setDNAStrandWithlengthOf:length]];
}
@end
