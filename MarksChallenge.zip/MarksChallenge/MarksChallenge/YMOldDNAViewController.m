//
//  YMOldDNAViewController.m
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import "YMOldDNAViewController.h"

@interface YMOldDNAViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) NSMutableArray *arrayForCorrentRow;//the array for every specific row (cell)
@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) YMOldDNACell *tableViewCell;
@end

@implementation YMOldDNAViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 60, self.view.frame.size.width, self.view.frame.size.height-60) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}
-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = NO;
}
-(NSMutableArray *)arrayForCorrentRow{
    if(!_arrayForCorrentRow){
        _arrayForCorrentRow = [[NSMutableArray alloc]init];
    }
    return _arrayForCorrentRow;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [YMPassData ymPassData].storedDNA.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"CellIdentifier";
    self.tableViewCell = (YMOldDNACell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(!self.tableViewCell){
        self.tableViewCell = [[YMOldDNACell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    self.tableViewCell.collectionView.tag = indexPath.row;
    //creating tap gesture on every cell. by taping on it, the sub-seuence view controller will presented
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tappedOnCell:)];
    [tap setNumberOfTouchesRequired:1];
    [tap setNumberOfTapsRequired:1];
    [self.tableViewCell.collectionView addGestureRecognizer:tap];
    [self.tableViewCell.collectionView setUserInteractionEnabled:YES];
    [self.tableViewCell.collectionView setTag:indexPath.row];
    return self.tableViewCell;
}
- (void)tappedOnCell:(UIGestureRecognizer *)sender {
    [YMPassData ymPassData].index = sender.view.tag;
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *vc = [[UIViewController alloc]init];
    vc = [storyBoard instantiateViewControllerWithIdentifier:@"subSeuenceVC"];
    [self showViewController:vc sender:nil];
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(YMOldDNACell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    [cell setCollectionViewDataSourceDelegate:self indexPath:indexPath];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
#pragma Table View Delegate
-(void)setEditing:(BOOL)editing animated:(BOOL)animated{
    [super setEditing:editing animated:animated];
    [self.tableView setEditing:editing animated:animated];
    [self.tableView reloadData];
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [[YMPassData ymPassData].storedDNA removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}
#pragma Collection View
//collection view that located in the table view cell
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    YMCollectionViewCell *cell = (YMCollectionViewCell*)[collectionView dequeueReusableCellWithReuseIdentifier:CollectionViewCellIdentifier forIndexPath:indexPath];
    self.arrayForCorrentRow = [YMPassData ymPassData].storedDNA[collectionView.tag];
    cell.nucleotidesView.text = self.arrayForCorrentRow[indexPath.row];
    
    //setting the background color of every collection view cell according to the text
    NSDictionary *setBackgroundColor = @{
                                         @"A" : [UIColor blueColor],
                                         @"C" : [UIColor greenColor],
                                         @"G" : [UIColor orangeColor],
                                         @"T" : [UIColor redColor],
                                         };
    cell.nucleotidesView.backgroundColor = [setBackgroundColor objectForKey:cell.nucleotidesView.text];
    
    
    return cell;
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    self.arrayForCorrentRow = [YMPassData ymPassData].storedDNA[collectionView.tag];
    return self.arrayForCorrentRow.count;
}

@end
