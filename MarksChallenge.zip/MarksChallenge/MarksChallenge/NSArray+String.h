//
//  NSArray+String.h
//  MarksChallenge
//
//  Created by Yoni on 06/11/2016.
//  Copyright © 2016 yoni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (String)
-(NSString*)toString;
@end
