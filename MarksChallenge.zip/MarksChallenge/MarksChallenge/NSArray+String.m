//
//  NSArray+String.m
//  MarksChallenge
//
//  Created by Yoni on 06/11/2016.
//  Copyright © 2016 yoni. All rights reserved.
//

#import "NSArray+String.h"

@implementation NSArray (String)
-(NSString *)toString{
    return [self componentsJoinedByString:@""];
}
@end
