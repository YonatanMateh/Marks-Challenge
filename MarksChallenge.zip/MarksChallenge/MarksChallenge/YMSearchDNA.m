//
//  YMSearchDNA.m
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import "YMSearchDNA.h"

@implementation YMSearchDNA

//check the most often chain that is in the DNA strand
+(NSMutableDictionary*)checkForDNAWithLength: (int)length InString:(NSArray*)array {
    NSString *string = [array toString];
    NSMutableDictionary *result = [[NSMutableDictionary alloc]init];
    int currentTimes = 0;
    int previous = 0;
    NSString *resultStr;
    for (int i=0; i<(string.length-length); i++) {
        if(i>length){
            break;
        }
        NSString * newString = [string substringWithRange:NSMakeRange(i,length)];
        NSRange searchRange = NSMakeRange(0, string.length-length-i);
        NSRange foundRange;
        currentTimes = 0;
        while (searchRange.location < string.length) {
            searchRange.length = string.length-searchRange.location;
            foundRange = [string rangeOfString:newString options:NSCaseInsensitiveSearch range:searchRange];
            if (foundRange.location != NSNotFound) {
                currentTimes++;
                searchRange.location = foundRange.location+foundRange.length;
            } else {
                break;
            }
        }
        if(currentTimes>previous){
            previous = currentTimes;
            resultStr = newString;
        }
    }
    [result setObject:[NSNumber numberWithInt:previous] forKey:@"amountOfTimes"];
    [result setObject:resultStr forKey:@"resultDNAString"];
    return result;
}
//check the position of the same chains like the the first x characters in the DNA
+(NSMutableIndexSet*)checkForTheFirstCharacterOfLength: (int)length InArray:(NSArray*)array {
    NSString *string = [array toString];
    NSMutableIndexSet *index = [[NSMutableIndexSet alloc]init];
    NSString * newString = [string substringWithRange:NSMakeRange(0,length)];
    NSRange searchRange = NSMakeRange(0, string.length-length);
    NSRange foundRange;
    while (searchRange.location < string.length) {
        searchRange.length = string.length-searchRange.location;
        foundRange = [string rangeOfString:newString options:NSCaseInsensitiveSearch range:searchRange];
        if (foundRange.location != NSNotFound) {
            // found
            searchRange.location = foundRange.location+foundRange.length;
            NSRange resultRange = NSMakeRange(foundRange.location, length);
            [index addIndexesInRange:resultRange];
        } else {
            break;
        }
    }
    return index;
}

@end
