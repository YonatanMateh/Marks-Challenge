//
//  YMOldDNACell.h
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YMCollectionView.h"
@interface YMOldDNACell : UITableViewCell
@property (strong, nonatomic) YMCollectionView *collectionView;
-(void)setContentOfSet :(CGPoint)contentOffset;
- (void)setCollectionViewDataSourceDelegate:(id<UICollectionViewDataSource, UICollectionViewDelegate>)dataSourceDelegate indexPath:(NSIndexPath *)indexPath;
@end
