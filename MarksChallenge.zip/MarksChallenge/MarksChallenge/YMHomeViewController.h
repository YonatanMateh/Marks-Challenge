//
//  YMHomeViewController.h
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YMHomeViewController : UIViewController

@end
