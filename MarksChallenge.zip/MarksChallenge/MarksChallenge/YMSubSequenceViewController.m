//
//  YMSubSequenceViewController.m
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import "YMSubSequenceViewController.h"
@interface YMSubSequenceViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) YMOldDNACell *cell;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityInd;
@property (weak, nonatomic) IBOutlet UIButton *shomMeBtn;
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;
@property (strong, nonatomic) UICollectionView *collectionRow1;
@property (weak, nonatomic) IBOutlet UILabel *instructions;
@property (strong, nonatomic) UICollectionView *collectionRow2;
@property (strong, nonatomic) NSMutableArray *arrayForCorrentRow;;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) NSMutableIndexSet *indexSet;
@property (strong, nonatomic) YMCollectionView *collectionView;
@property (strong, nonatomic) YMSetDNAStrand *setDNA;
@property (strong, nonatomic) NSMutableArray *dnaForSearch;
@end

@implementation YMSubSequenceViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.instructions.hidden = YES;
    self.tableView.scrollEnabled = NO;
    self.resultLabel.text = @"";
    self.shomMeBtn.layer.cornerRadius = 3.5;
    self.arrayForCorrentRow = [YMPassData ymPassData].storedDNA[[YMPassData ymPassData].index];
    [self.tableView reloadData];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    self.activityInd.hidden = YES;
    self.navigationController.navigationBar.hidden = NO;
}

-(YMCollectionView *)collectionView{
    if(!_collectionView){
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(40, 40);
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        _collectionView = [[YMCollectionView alloc]initWithFrame:CGRectMake(0.5, 156, self.view.frame.size.width, 55) collectionViewLayout:layout];
        [_collectionView registerClass:[YMCollectionViewCell class] forCellWithReuseIdentifier:CollectionViewCellIdentifier];
        _collectionView.backgroundColor = [UIColor clearColor];
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        [self.view addSubview:_collectionView];
    }
    return _collectionView;
}
-(YMSetDNAStrand *)setDNA{
    if(!_setDNA){
        _setDNA = [[YMSetDNAStrand alloc]init];
    }
    return _setDNA;
}
-(void)dismissKeyboard {
    [self.textField resignFirstResponder];
}
-(UITableView *)tableView{
    if(!_tableView){
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0,62, self.view.frame.size.width, 105) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
    }
    return _tableView;
}
-(NSMutableArray *)arrayForCorrentRow{
    if(!_arrayForCorrentRow){
        _arrayForCorrentRow = [[NSMutableArray alloc]init];
    }
    return _arrayForCorrentRow;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"CellIdentifier";
    _cell = (YMOldDNACell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(!_cell){
        _cell = [[YMOldDNACell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    if(indexPath.row == 0){
        self.collectionRow2 = self.cell.collectionView;
    }else if (indexPath.row == 1){
        self.collectionRow1 = self.cell.collectionView;
    }
    _cell.selectionStyle = UITableViewCellSelectionStyleNone;
    _cell.collectionView.tag = indexPath.row;
    return _cell;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(YMOldDNACell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    [_cell setCollectionViewDataSourceDelegate:self indexPath:indexPath];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
#pragma Table View Delegate
-(void)setEditing:(BOOL)editing animated:(BOOL)animated{
    [super setEditing:editing animated:animated];
    [self.tableView setEditing:editing animated:animated];
}
#pragma Collection View
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    YMCollectionViewCell *cell = (YMCollectionViewCell*)[collectionView dequeueReusableCellWithReuseIdentifier:CollectionViewCellIdentifier forIndexPath:indexPath];
    cell.nucleotidesView.text = self.arrayForCorrentRow[indexPath.row];
    cell = [self setBackroundColor:cell inCollectionView:collectionView];
    
    if (self.shomMeBtn.isSelected) {
        //changing the background of the searchd chains
        if([self.indexSet containsIndex:indexPath.row]){
            cell.nucleotidesView.backgroundColor = [UIColor blackColor];
        }
    }
    return cell;
}

-(YMCollectionViewCell*)setBackroundColor :(YMCollectionViewCell*)collectionViewCell inCollectionView: (UICollectionView*)collectionView{
    
    YMCollectionViewCell *cell = collectionViewCell;
    //replacing the parallel chain
    NSDictionary *setChar = @{
                              @"A" : @"T", @"C" : @"G", @"G" : @"C", @"T" : @"A"
                              };
    if (collectionView == self.collectionRow1) {
        cell.nucleotidesView.text = [setChar objectForKey:cell.nucleotidesView.text];
    }
    
    NSDictionary *setBackgroundColor = @{
                                         @"A" : [UIColor blueColor],@"C" : [UIColor greenColor],@"G" : [UIColor orangeColor],@"T" : [UIColor redColor]
                                         };
    cell.nucleotidesView.backgroundColor = [setBackgroundColor objectForKey:cell.nucleotidesView.text];
    return cell;
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.arrayForCorrentRow.count;
}
- (IBAction)showMeAction:(id)sender {
    //checking that the user typed number
    if (self.textField.text.length > 0) {
        int lengthOfStrand = [self.textField.text intValue];
        if(lengthOfStrand<self.arrayForCorrentRow.count){
            self.shomMeBtn.selected = !self.shomMeBtn.isSelected;
            [self.activityInd startAnimating];
            self.activityInd.hidden = NO;
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                NSMutableDictionary *results;
                if(self.shomMeBtn.isSelected){
                    self.indexSet = [YMSearchDNA checkForTheFirstCharacterOfLength:lengthOfStrand InArray:self.arrayForCorrentRow];
                }else{
                    results = [YMSearchDNA checkForDNAWithLength:lengthOfStrand InString:[[YMPassData ymPassData].storedDNA lastObject]];
                    
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    if([[results objectForKey:@"amountOfTimes"]intValue]>1){
                        self.resultLabel.text = [NSString stringWithFormat:@"The sub-sequence strand that is repeated most often is: %@. It is repeated \"%@\" times.",[results objectForKey:@"resultDNAString"],[results objectForKey:@"amountOfTimes"]];
                    }else{
                        self.resultLabel.text = @"There is not any sub-sequence strand that repeated more than one time!";
                    }
                    [self.activityInd stopAnimating];
                    self.activityInd.hidden = YES;
                    [self.collectionRow1 reloadData];
                    [self.collectionRow2 reloadData];
                    
                    //presenting the correct label
                    if(self.shomMeBtn.isSelected){
                        self.instructions.hidden = NO;
                        self.resultLabel.hidden = YES;
                    }else{
                        self.instructions.hidden = YES;
                        self.resultLabel.hidden = NO;
                    }
                });
            });
        }else{
            [self alertControllerWithMessage:@"You need to type number that is smaller then the DNA length"];
        }
    }else{
        [self alertControllerWithMessage:@"You did not type any number!"];
    }
}
-(void)alertControllerWithMessage: (NSString*)message{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Oops!" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Got it" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}
#pragma Scroll View Delegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //setting the two collection view to scroll together
    if (scrollView == self.collectionRow1) {
        self.collectionRow2.contentOffset = self.collectionRow1.contentOffset;
    } else if (scrollView == self.collectionRow2) {
        self.collectionRow1.contentOffset = self.collectionRow2.contentOffset;
    }
}
@end
