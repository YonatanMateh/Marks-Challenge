//
//  YMCollectionViewCell.m
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import "YMCollectionViewCell.h"

@implementation YMCollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.nucleotidesView = [[UILabel alloc]initWithFrame:CGRectMake(1, 2, 40, 40)];
        self.nucleotidesView.backgroundColor = [UIColor brownColor];
        [self.viewForLastBaselineLayout addSubview:self.nucleotidesView];
        self.nucleotidesView.layer.masksToBounds = YES;
        self.nucleotidesView.layer.cornerRadius = 40/2;
        self.nucleotidesView.textColor = [UIColor whiteColor];
        self.nucleotidesView.font = [UIFont boldSystemFontOfSize:18];
        self.nucleotidesView.textAlignment = NSTextAlignmentCenter;
        self.nucleotidesView.layer.borderColor = [UIColor blackColor].CGColor;
        self.nucleotidesView.layer.borderWidth = 1.6;
    }
    return self;
}
@end
