//
//  YMSetDNAStrand.m
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import "YMSetDNAStrand.h"

@implementation YMSetDNAStrand
//sets array of random characters for the DNA strand
-(NSArray*)nucleotides
{
    if(!_nucleotides){
        _nucleotides = [[NSArray alloc]initWithObjects:@"A",@"C",@"G",@"T", nil];
    }
    return _nucleotides;
}
-(NSMutableArray*)setDNAStrandWithlengthOf: (int)length{
    NSMutableArray *result = [[NSMutableArray alloc]init];
    for (int i = 0; i<length; i++) {
        [result addObject:self.nucleotides[arc4random() % self.nucleotides.count]];
    }
    return result;
}

@end
