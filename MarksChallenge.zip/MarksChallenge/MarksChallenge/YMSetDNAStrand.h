//
//  YMSetDNAStrand.h
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YMSetDNAStrand : NSObject
@property (strong, nonatomic) NSArray *nucleotides;
-(NSMutableArray*)setDNAStrandWithlengthOf: (int)length;
@end
