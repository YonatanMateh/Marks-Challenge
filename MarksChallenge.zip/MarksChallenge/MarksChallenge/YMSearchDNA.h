//
//  YMSearchDNA.h
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YMSearchDNA : NSObject
+(NSMutableDictionary*)checkForDNAWithLength: (int)length InString:(NSArray*)array;
+(NSMutableIndexSet*)checkForTheFirstCharacterOfLength: (int)length InArray:(NSArray*)array;
@end
