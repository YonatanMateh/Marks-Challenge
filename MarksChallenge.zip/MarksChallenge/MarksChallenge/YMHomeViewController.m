//
//  YMHomeViewController.m
//  MarksChallenge
//
//  Created by yoni on 6/14/16.
//  Copyright © 2016 yoni. All rights reserved.
//
//This Class is the view controller of the first screen
#import "YMHomeViewController.h"

@interface YMHomeViewController ()
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityInd;
@property (weak, nonatomic) IBOutlet UITextField *chooseNumberTextField;
@property (strong, nonatomic) YMSetDNAStrand *setDNA;
@property (weak, nonatomic) IBOutlet UIButton *loadBtn;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;
@property (weak, nonatomic) IBOutlet UIButton *calculateBtn;
@property (nonatomic) bool isClickedSave;
@end

@implementation YMHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isClickedSave = NO;
    self.saveBtn.layer.cornerRadius = 3.5;
    self.loadBtn.layer.cornerRadius = 3.5;
    self.calculateBtn.layer.cornerRadius = 3.5;
    self.setDNA = [[YMSetDNAStrand alloc]init];
    self.activityInd.hidden = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
}
-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = YES;
}
-(void)dismissKeyboard {
    [self.chooseNumberTextField resignFirstResponder];
}

- (IBAction)saveDNAAction:(id)sender {
    //saves the DNA strand
    if(self.chooseNumberTextField.text.length>0){
        if(self.isClickedSave){
            [self saveVerification];
        }else{
            [self saveDNA];
        }
    }else{
        [self youNeedToTypeAlertView];
    }
}
/**
 Checking if the user want to add another DNA strand
 */
-(void)saveVerification{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Save" message:@"Are you sure you want to save another DNA strand" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *yes = [UIAlertAction actionWithTitle:@"Yes" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:nil];
        [self saveDNA];
    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"No" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:yes];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
    
}
-(void)saveDNA{
    int lengthOfStrand = [self.chooseNumberTextField.text intValue];
    [self.activityInd startAnimating];
    self.activityInd.hidden = NO;
    //saving the DNA strand
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[YMPassData ymPassData]addDNASequenceOfLength:lengthOfStrand];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.activityInd stopAnimating];
            self.activityInd.hidden = YES;
            self.isClickedSave = YES;
        });
    });
}
- (IBAction)LoadExistingDNA:(id)sender {
    if([YMPassData ymPassData].storedDNA.count>0){
        //presenting the existing view controller
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *vc = [storyBoard instantiateViewControllerWithIdentifier:@"oldDnaVC"];
        [self showViewController:vc sender:nil];
    }else{
        [self youNeedToTypeAlertView];
    }
}
- (IBAction)TypeSubSequenceNumber:(id)sender {
    if([YMPassData ymPassData].storedDNA.count>0){
        [YMPassData ymPassData].index = [YMPassData ymPassData].storedDNA.count-1;
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *vc = [storyBoard instantiateViewControllerWithIdentifier:@"subSeuenceVC"];
        [self showViewController:vc sender:nil];
    }else{
        [self youNeedToTypeAlertView];
    }
}
/**
 Alert Controller that will presented if the user didn't type anything
 */
-(void)youNeedToTypeAlertView{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Oops..." message:@"You need to type the length of the DNA strand" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Got it" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
